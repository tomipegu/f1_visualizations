from dash import html
import dash_bootstrap_components as dbc

from app import app


def layout():
    return [
        html.Div
        (
            [
                dbc.Row(
                    [
                        dbc.Col
                        (
                            [
                                html.Img(
                                    src=app.get_asset_url("logo.png"),
                                    height="40px",
                                    style={'margin-top': '1.5%', 'margin-bottom': '1.5%', 'margin-left': '1.25%'}
                                ),
                            ],
                        ),

                        dbc.Col
                        (
                            [
                                dbc.NavLink("Home", href=app.get_relative_path("/home"), style={'color': 'white'})
                            ],
                            style={'padding-left': '1100px', 'margin-top': '1.5%', 'margin-bottom': '1.5%', 'margin'
                                                                                                            '-left':
                                '1.25%'}
                        )
                    ],
                    align="center",
                    style={
                        'background-color': 'black',
                        'height': '15%',
                        'opacity': 0.85
                    }

                )
            ],
        ),
        html.Div
        (
            style=
            {
                "background-image": "url(assets/our_team.jpg)",
                'position': 'fixed',
                'width': '100%',
                'height': '100%',
                'background-position': 'center',
                'background-repeat': 'no-repeat',
                'background-size': 'cover',
            }
        )
    ]
