import plotly.graph_objects as go
import plotly.express as px
import dash
from dash import dcc, html, Input, Output, callback, dash_table
import dash_bootstrap_components as dbc
from dash.exceptions import PreventUpdate

from data_reader import *
from app import app

# Años de competición hasta ahora
f1_seasons = list(historico_temporadas.sort_values('year', ascending=False)["year"])


# [FUNCIÓN] Calcular el Ranking Anual de Constructores
def get_yearly_constructors_ranking(year):
    constructors_ranking = df_constructor_ranking[df_constructor_ranking['Year'] == year]
    return constructors_ranking[['Constructor', 'Nationality', 'Points', 'Wins']]


# [FUNCIÓN] Calcular la distribución de las nacionalidades de los constructores
def get_constructors_nationality_distribution(year):
    # Determinamos el número y porcentaje de constructores de cada nacionalidad
    nacionalidades_constructores = df_constructor_ranking.copy()[df_constructor_ranking['Year'] == year][
        ['constructorId', 'Nationality']].drop_duplicates()
    nacionalidades_constructores = nacionalidades_constructores.groupby('Nationality')[
        'Nationality'].count().sort_values(ascending=False).reset_index(name='numero_constructores')
    nacionalidades_constructores['porcentaje'] = ((nacionalidades_constructores['numero_constructores'] / sum(
        nacionalidades_constructores["numero_constructores"])) * 100).round(2)
    # Agrupamos las nacionalidades que sean menor de 1% bajo la categoría otro y calculamos el porcentaje total
    numero_constructores = nacionalidades_constructores[nacionalidades_constructores['porcentaje'] < 1][
        'numero_constructores'].sum()
    porcentaje = nacionalidades_constructores[nacionalidades_constructores['porcentaje'] < 1]['porcentaje'].sum()
    nacionalidades_constructores_agrupado = nacionalidades_constructores[nacionalidades_constructores['porcentaje'] > 1]
    fila_agrupado = {'nationality': 'Other nationalities', 'numero_constructores': numero_constructores,
                     'porcentaje': porcentaje}
    nacionalidades_constructores_agrupado = nacionalidades_constructores_agrupado.append(fila_agrupado,
                                                                                         ignore_index=True)
    return nacionalidades_constructores_agrupado


# [FUNCIÓN] Barplot Antiguedad Constructores
def get_constructor_years_barplot():
    fig = px.bar(df_constructor_years, x='Constructor', y='numero_campeonatos',
                 hover_data=['Constructor', 'numero_campeonatos'], color='numero_campeonatos', height=400,
                 color_continuous_scale='YlOrRd')

    fig.update_layout(title='Nº Temporadas Competidas de cada Escudería',
                      xaxis_title='Escudería',
                      yaxis_title='Nº Temporadas')

    return fig


def layout():
    return [
        html.Div(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Card(
                                    dbc.CardBody(
                                        [
                                            dbc.CardHeader("Ranking Escuderías:"),
                                            dcc.Dropdown(
                                                id="constructor-year-dropdown",
                                                options=[
                                                    {"label": i, "value": i} for i in f1_seasons
                                                ],
                                                clearable=False,
                                                searchable=True,
                                                value=2020,
                                            ),
                                            html.Div(id="constructor-standings-card"),
                                        ]
                                    ),
                                    color = 'danger',
                                    outline = True
                                ),
                            ],
                            width=5
                        ),

                        dbc.Col(
                            [

                                
                                dbc.Row(
                                    [
                                        dbc.Card(
                                            dcc.Graph(
                                                id="constructors-nationality-pie-graph",
                                                style={
                                                    "display": "block"
                                                }
                                            ),
                                            color = 'danger',
                                            outline = True
                                        )
                                    ]
                                )
                            ],
                            width=5
                        )
                    ],
                    align = 'end',
                    justify='center',
                    style = {
                        'margin':'auto',
                        'margin-top': '2.5%',
                        'margin-bottom': '2.5%'
                    }
                ),

                dbc.Row
                (
                    [
                        dbc.Col
                        (
                            [
                                dbc.Card(
                                    dcc.Graph
                                    (
                                        id="constructor-years-barplot",
                                        style={
                                            "display": "block"
                                        },
                                        figure=get_constructor_years_barplot()
                                    ),
                                    color = 'danger',
                                    outline = True
                                )
                            ],
                            width=11
                        ),
                    ],
                    justify='center',
                    style = {
                        'margin':'auto',
                        'margin-bottom': '2.5%'
                    }
                )
            ]
        )
    ]


@app.callback(
    Output("constructor-standings-card", "children"),
    [Input("constructor-year-dropdown", "value")],
)
def get_constructor_ranking_callback(year):
    if year is not None:
        df = get_yearly_constructors_ranking(year)
        return dash_table.DataTable(
            columns=[{"name": i, "id": i} for i in df.columns],
            data=df.to_dict("records"),
            page_current=0,
            style_header={"backgroundColor": "white", "fontWeight": "bold"},
            style_cell={"textAlign": "center"},
            style_cell_conditional=[
                {"if": {"column_id": "Finished"}, "textAlign": "center"}
            ],
            style_as_list_view=True,
        )
    else:
        raise PreventUpdate


@app.callback(
    Output("constructors-nationality-pie-graph", "figure"),
    [Input("constructor-year-dropdown", "value")],
)
def year_driver_nationality_distribution_callback(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        nacionalidades_escuderias = get_constructors_nationality_distribution(year_range)

        fig = go.Figure(
            data=[go.Pie(labels=nacionalidades_escuderias['Nationality'],
                         values=nacionalidades_escuderias['numero_constructores'])])
        fig.update_traces(textfont_size=20, marker=dict(line=dict(color='#000000', width=2)))
        fig.update_layout(title="Nacionalidad de las escuderías")

        return fig
