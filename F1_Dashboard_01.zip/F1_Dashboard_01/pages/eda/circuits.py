import os
import plotly.graph_objects as go
import plotly.express as px
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc
from dash.exceptions import PreventUpdate

from data_reader import *
from app import app

# Fichero Imagenes Circuitos
# Abrimos fichero
files = os.listdir("assets/images/circuits")
# Comprobamos que el nombre de los ficheros coincida con nuestros datos
circuit_list = [x.split(".")[0] for x in files]
# Creeamos un dataframe con el nombre y referencia de los circuitos
df_circuit_images = circuitos[circuitos['circuitRef'].isin(circuit_list)][['circuitId', 'circuitRef', 'name']]


# MAPA
def get_map():
    # Extraemos la lista de circuitos en los que se ha corrido cada año
    df_circuitos_anuales = historico_carreras[['year', 'circuitId']]
    # Calculamos el número de veces que se ha competido en cada circuito
    df_carreras_por_circuito = df_circuitos_anuales.groupby(['circuitId'], as_index=False).count().rename(
        columns={'year': 'n_carreras'})
    # Extraemos el año de la última carrera realizada en cada circuito
    df_carreras_por_circuito['last_year'] = df_circuitos_anuales.groupby(['circuitId'], as_index=False)['year'].max()[
        'year']
    # Extraemos la localización geográfica de cada circuito (latitud, longitud)
    df = circuitos[['circuitId', 'name', 'lat', 'lng']].merge(df_carreras_por_circuito, how='left', on='circuitId')
    fig = go.Figure()

    fig.add_trace(go.Scattermapbox(
        lon=df['lng'],
        lat=df['lat'],
        text=df['name'] + '<br>Nº Carreras: ' + (df['n_carreras']).astype(
            str) + '<br>Última Carrera: ' + (df['last_year']).astype(str),
        marker=dict(
            size=df['n_carreras'],
            # color = df_carrerasPorCircuito['n_carreras']
        )
    ))

    fig.update_layout(
        title='Nº Carreras por Circuito [Histórico]',
        height=800,
        width=800,
        hovermode='closest',
        showlegend=False,
        mapbox_style='carto-positron',
    )

    return fig


# Número carreras por año
def get_races_by_year(years_range):
    carreras_historico = historico_carreras.copy()[
        historico_carreras['year'].isin(list(range(years_range[0], years_range[1] + 1)))]
    df_races_plot = carreras_historico['year'].value_counts().reset_index()
    df_races_plot.columns = ['Year', 'Races']
    df_races_plot.rename(columns={'Year': 'Races'})
    df_races_plot.sort_values(by=['Year'], inplace=True)
    df_races_plot.sort_values(by=['Year'])

    return df_races_plot


# [FUNCIÓN] Obtener imagen del trazado de un circuito


def layout():
    return [
        html.Div
        (
            [
                dbc.Row
                (
                    children=[
                        dbc.Col
                        (
                            [
                                dcc.Graph
                                (
                                    id="map_graph",
                                    style={
                                        "display": "block"
                                    },
                                    figure=get_map()
                                )
                            ],
                            width=6
                        ),

                        dbc.Col
                        (
                            [
                                dbc.Card(
                                    [
                                        dbc.CardHeader("Circuito:"),
                                        dbc.CardBody(
                                            children=[
                                                dcc.Dropdown(
                                                    id="circuits-dropdown",
                                                    options=[
                                                        {"label": i, "value": i}
                                                        for i in list(df_circuit_images['name'])
                                                    ],
                                                    clearable=False,
                                                    searchable=True,
                                                    value="Albert Park Grand Prix Circuit",
                                                    style={"width": "300px"},
                                                ),

                                                html.Img(
                                                    id="circuit-layout",
                                                    style={"height": "450px", "width": "700px"},
                                                )
                                            ]
                                        ),
                                    ]
                                ),
                            ],
                            width=6
                        )
                    ]
                ),

                dbc.Row
                (
                    [
                        dbc.Col
                        (
                            [
                                dbc.Row
                                (
                                    [
                                        dbc.Label("Years", html_for="years-slider"),
                                        dcc.RangeSlider(id="years_races-range-slider",
                                                        min=1950,
                                                        max=2020,
                                                        step=5,
                                                        value=[1950, 2020],
                                                        marks={1950: "1950", 1960: "1960", 1970: "1970", 1980: "1980",
                                                               1990: "1990", 2000: "2000", 2010: "2010", 2020: "2020"})
                                    ],
                                    justify="center",
                                    align="center"
                                ),
                                dbc.Row
                                (
                                    [
                                        dcc.Graph
                                        (
                                            id="races_by_year",
                                            style={
                                                "display": "block"
                                            },
                                        )
                                    ],
                                    justify="center",
                                    align="center"
                                )
                            ],
                            width=12
                        )
                    ]
                )
            ]
        )
    ]


@app.callback(
    Output("races_by_year", "figure"),
    [Input("years_races-range-slider", "value")]
)
def races_by_year_callback(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        df_races_plot = get_races_by_year(year_range)

        fig = px.bar(df_races_plot, x='Year', y='Races',
                     hover_data=['Year', 'Races'], color='Races', height=400)

        fig.update_layout(title='Nº Carreras por Año',
                          xaxis_title='Año',
                          yaxis_title='Nº Carreras',
                          yaxis_ticksuffix="%")

        return fig


@app.callback(Output("circuit-layout", "src"), [Input("circuits-dropdown", "value")])
def get_circuit_layout_callback(name):
    if name is not None:
        df = df_circuit_images[df_circuit_images['name'] == name]
        file_name = df['circuitRef'].values[0]
        return app.get_asset_url("images/circuits/{}.png").format(file_name)
    else:
        raise PreventUpdate
