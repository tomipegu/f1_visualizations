import plotly.graph_objects as go
import plotly.express as px
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc

from data_reader import *
from app import app


# [FUNCION] Calcular la distribución de conductores por nacionalidad
def get_driver_nationality_distribution(year_range):
    pilotos_anuales = df_nacionalidad_conductores.copy()[
        df_nacionalidad_conductores['race_year'].isin(list(range(year_range[0], year_range[1] + 1)))][
        ['driverId', 'nationality']].drop_duplicates()
    nacionalidades_pilotos = pilotos_anuales.groupby('nationality')['nationality'].count().sort_values(
        ascending=False).reset_index(name='numero_pilotos')
    nacionalidades_pilotos['porcentaje'] = (
            (nacionalidades_pilotos['numero_pilotos'] / len(pilotos_anuales)) * 100).round(2)
    return nacionalidades_pilotos


# [FUNCION] Calcular la distribución agrupada de conductores por nacionalidad
def get_driver_nationality_grouped_distribution(year_range):
    # Nacionalidades pilotos sin agrupar
    nacionalidades_pilotos = get_driver_nationality_distribution(year_range)
    # Agrupamos los que sean menor de 3.0%% bajo la categoría otro y calculamos ese porcentaje total
    if len(nacionalidades_pilotos[nacionalidades_pilotos['porcentaje'] < 3.00]) > 0:
        numero_pilotos = nacionalidades_pilotos[nacionalidades_pilotos['porcentaje'] < 3.00]['numero_pilotos'].sum()
        porcentaje = nacionalidades_pilotos[nacionalidades_pilotos['porcentaje'] < 3.00]['porcentaje'].sum()
        nacionalidades_pilotos_agrupado = nacionalidades_pilotos[nacionalidades_pilotos['porcentaje'] > 3.00]
        fila_agrupado = {'nationality': 'Other', 'numero_pilotos': numero_pilotos,
                         'porcentaje': porcentaje}
        nacionalidades_pilotos_agrupado = nacionalidades_pilotos_agrupado.append(fila_agrupado, ignore_index=True)
        return nacionalidades_pilotos_agrupado
    else:
        return nacionalidades_pilotos


# [FUNCION] Calcular el porcentaje de campeones con respecto al número total de pilotos por país
def get_winners_nationality_distribution(year_range):
    # Filtramos la información de los campeones por fecha
    f1_champions_info = df_f1_champions_info[
        df_f1_champions_info['year'].isin(list(range(year_range[0], year_range[1] + 1)))]
    # Calculamos el número de campeones por nacionalidad
    champions_per_nationality = f1_champions_info.groupby('nationality')['driverId'].nunique().reset_index(
        name='numero_campeones').sort_values(by='numero_campeones')
    # Calculamos el ratio de pilotos ganadores respecto al número de pilotos por país
    champions_nationality_ratio = champions_per_nationality.merge(get_driver_nationality_distribution(year_range),
                                                                  on='nationality', how='inner')
    champions_nationality_ratio['porcentaje_ganadores'] = (
            champions_nationality_ratio['numero_campeones'] / champions_nationality_ratio['numero_pilotos'] * 100).round(2)
    champions_nationality_ratio = champions_nationality_ratio.sort_values('porcentaje_ganadores', ascending=False)
    return champions_nationality_ratio


# [FUNCION] Calcular el porcentaje medio de pilotos que terminan las carreras por año
def get_avg_yearly_percentage_finished_races(year_range):
    # Se halla el porcentaje de los id status para cada carrera
    df = dataset_reduced[dataset_reduced['race_year'].isin(list(range(year_range[0], year_range[1] + 1)))][
        ['race_year', 'raceId', 'statusId']]
    porcentaje = df.groupby(['race_year', 'raceId'])['statusId'].value_counts(normalize=True).reset_index(
        name="porcentaje")
    # Se halla el porcentaje de los conductores que sí terminaron la carrera (status IDs: 1, 11-19) y se suman
    porcentaje_terminado = porcentaje.loc[porcentaje['statusId'].isin([1, 11, 12, 13, 14, 15, 16, 17, 18, 19])]
    porcentaje_terminado = porcentaje_terminado.groupby(['race_year', 'raceId'])['porcentaje'].sum().reset_index(
        name='porcentaje_terminados')
    # Se agrupa por año y se obtiene la media
    porcentaje_terminado = porcentaje_terminado.groupby(['race_year'])['porcentaje_terminados'].mean().reset_index(
        name='media_porcentaje_terminados')
    porcentaje_terminado['media_porcentaje_terminados'] = (
            porcentaje_terminado['media_porcentaje_terminados'] * 100).round(2)
    return porcentaje_terminado


# LAYOUT PÁGINA
def layout():
    return [

        html.Div(
            [
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Label("Year", html_for="range-slider"),
                                dcc.RangeSlider(id="drivers-year-range-slider",
                                                min=1997,
                                                max=2022,
                                                step=1,
                                                value=[1997, 2022],
                                                marks={i: str(i) for i in range(1997, 2023)})
                            ],
                            width=8,
                            style = {
                                'margin':'auto',
                                'margin-bottom': '2.5%'
                            }
                        )
                    ]
                ),

                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Card(
                                    dcc.Graph(
                                        id="drivers-points-per-age-hist-graph",
                                        style={
                                            "display": "block"
                                        }
                                    ),
                                    color="danger", outline=True
                                )
                            ],
                            width=5
                        ),

                        dbc.Col(
                            [
                                dbc.Card(
                                    dcc.Graph(
                                        id="drivers-nationality-pie-graph",
                                        style={
                                            "display": "block"
                                        }
                                    ),
                                    color="danger", outline=True
                                )
                            ],
                            width=5
                        ),
                    ],
                    justify='center',
                    style = {
                        'margin':'auto',
                        'margin-bottom': '2.5%'
                    }
                ),

                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Card(
                                    dcc.Graph(
                                        id="drivers-winners-per-nationality-graph",
                                        style={
                                            "display": "block"
                                        }
                                    ),
                                    color="danger", outline=True
                                )
                            ],
                            width=5
                        ),

                        dbc.Col(
                            [
                                dbc.Card(
                                    dcc.Graph(
                                        id="drivers-yearly-race-endings-graph",
                                        style={
                                            "display": "block"
                                        }
                                    ),
                                    color="danger", outline=True
                                )
                            ],
                            width=5
                        )
                    ],
                    justify='center',
                    style = {
                        'margin':'auto',
                        'margin-bottom': '2.5%'
                    }
                )
            ],
            style = {
                'margin-left':'1.5%',
                'margin-right':'1.5%'
            }
        ),
    ]


@app.callback(
    Output("drivers-points-per-age-hist-graph", "figure"),
    [Input("drivers-year-range-slider", "value")]
)
def year_driver_points_age_hist_callback(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        data = dataset_reduced[dataset_reduced["race_year"].isin(list(range(year_range[0], year_range[1] + 1)))]

        fig = go.Figure()
        fig.add_trace(
            go.Histogram(
                x=data["age"],
                y=data["driver_points"],
                xbins=dict(
                    start=0,
                    end=50,
                    size=1,
                ),
                marker_color="#c3423f"
            )
        )
        fig.update_layout(title="Distribución de Puntos de Conductores por Edad",
                          xaxis_title="Edad",
                          yaxis_title="Puntos")

        return fig


@app.callback(
    Output("drivers-nationality-pie-graph", "figure"),
    [Input("drivers-year-range-slider", "value")]
)
def year_driver_nationality_distribution_callback(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        nacionalidades_pilotos = get_driver_nationality_grouped_distribution(year_range)

        fig = go.Figure(
            data=[
                go.Pie(labels=nacionalidades_pilotos['nationality'], values=nacionalidades_pilotos['numero_pilotos'])])
        fig.update_traces(textfont_size=20, marker=dict(line=dict(color='#000000', width=2)))
        fig.update_layout(title="Nacionalidad de los pilotos")

        return fig


@app.callback(
    Output("drivers-winners-per-nationality-graph", "figure"),
    [Input("drivers-year-range-slider", "value")]
)
def year_driver_winners_per_nationality_distribution_callback(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        ratio = get_winners_nationality_distribution(year_range)

        fig = px.bar(ratio, x='nationality', y='porcentaje_ganadores',
                     hover_data=['numero_campeones', 'numero_pilotos'],
                     color='numero_pilotos',
                     color_continuous_scale='YlOrRd')
        fig.update_traces(textfont_size=20, marker=dict(line=dict(color='#000000', width=2)))
        fig.update_layout(title="% ganadores por número total de pilotos por país")

        return fig


@app.callback(
    Output("drivers-yearly-race-endings-graph", "figure"),
    [Input("drivers-year-range-slider", "value")]
)
def year_driver_yearly_race_endings_callback(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        porcentaje_terminado = get_avg_yearly_percentage_finished_races(year_range)

        fig = px.bar(porcentaje_terminado, x='race_year', y='media_porcentaje_terminados',
                     labels=dict(year="Year", avg_finish_prct="Percentage"),
                     title='Porcentaje medio de pilotos que terminan las carreras por año')

        fig.update_layout(plot_bgcolor='gainsboro'),
        fig.update_traces(marker_color="#c3423f")
        fig.update_yaxes(showgrid=True, gridwidth=1, range=[0, 100])

        return fig
