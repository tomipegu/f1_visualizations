import plotly.graph_objects as go
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc

from data_reader import *
from app import app

# Datos a emplear
df = historico_carreras.copy()


def layout():
    return [
        html.Div(
            [
                dbc.Row(
                    children=[
                        dbc.Col(
                            children=[
                                dbc.Label("Year", html_for="range-slider"),
                                dcc.RangeSlider(id="range-slider",
                                                min=1997,
                                                max=2022,
                                                step=1,
                                                value=[1997, 2022],
                                                marks={i: str(i) for i in range(1997, 2023)})
                            ], width=8
                        )
                    ]
                ),

                dbc.Row(
                    children=[
                        dbc.Col(
                            children=[
                                dcc.Graph(
                                    id="yearly-graph",
                                    style={
                                        "display": "block"
                                    }
                                )
                            ], width=8
                        )
                    ]

                )

            ]
        )
    ]


@app.callback(
    Output("yearly-graph", "figure"),
    [Input("range-slider", "value")]
)
def year_callback(year):
    if (year is None) or (year == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        fig = go.Figure()
        fig.add_trace(
            go.Histogram(
                x=df[df["year"].isin(list(range(year[0], year[1] + 1)))]["year"],
                xbins=dict(
                    start=year[0],
                    end=year[1],
                    size=5,
                ),
                marker_color="steelblue"
            )
        )
        return fig
