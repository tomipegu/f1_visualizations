import requests
from bs4 import BeautifulSoup
from dash import dcc, html, Input, Output
import plotly.graph_objects as go
import dash_bootstrap_components as dbc
from dash.exceptions import PreventUpdate

from data_reader import *
from app import app

# Lista de conductores
list_driver_names = list(df_driver_info.sort_values('name')['name'].values)


# [FUNCION] Imagen Conductor
def get_driver_photo(driver_name):
    # URL Wikipedia
    wikipedia_url = df_driver_info[df_driver_info['name'] == driver_name]['url'].values[0]
    # Abrimos página Wikipedia
    r = requests.get(wikipedia_url)
    # Extraemos la URL de la imagen del conductor con Beautiful Soup
    try:
        soup_driver_image_url = BeautifulSoup(r.text, 'html.parser').select('body')[0] \
            .find_all("td", {"class": "infobox-image"})[0] \
            .find_all("img")[0]['src']
    except:
        return None

    # Retornamos la URL completa                                                         
    if soup_driver_image_url is None:
        return None
    else:
        return "https:" + soup_driver_image_url


def layout():
    return [
        dbc.Row
        (
            [
                dbc.Col
                (
                    [
                        dbc.Card(
                            dbc.CardBody(
                                children=[
                                    dbc.CardHeader("Seleccionar Piloto: "),
                                    dcc.Dropdown(
                                        id="driver-name-dropdown",
                                        options=[
                                            {"label": i, "value": i}
                                            for i in list_driver_names
                                        ],
                                        clearable=False,
                                        searchable=True,
                                        value="Fernando Alonso",
                                    ),
                                    dbc.Row(
                                        children=[
                                            dbc.Col(
                                                [
                                                    html.Img(
                                                        id="driver-image-card",
                                                        style={
                                                            "padding-top": "10%",
                                                            "height": "293px",
                                                            "width": "220px",
                                                            "padding-left": "5%",
                                                        },
                                                    )
                                                ],
                                                width=6
                                            ),

                                            dbc.Col(
                                                [
                                                    html.Div(
                                                        id="driver-info-card",
                                                        style={
                                                            "padding-left": "5%",
                                                            "padding-top": "10%",
                                                        },
                                                    ),
                                                ],
                                                width=6
                                            )

                                        ]
                                    ),
                                ]
                            ),
                            style={
                                'margin-top': '2.5%'
                            }
                        ),
                    ],
                    width=4
                ),

                dbc.Col
                (
                    [
                        dcc.Graph(
                            id="driver-yearly-evolution",
                            style={
                                "display": "block"
                            }
                        )
                    ],
                    width=8

                )
            ]
        )
    ]


@app.callback(Output("driver-image-card", "src"), [Input("driver-name-dropdown", "value")])
def get_driver_image_card(name):
    if name is not None:
        driver_image = get_driver_photo(name)
        if driver_image is None:
            return app.get_asset_url("no_image.jpg")
        else:
            return driver_image
    else:
        raise PreventUpdate


@app.callback(
    Output("driver-info-card", "children"), [Input("driver-name-dropdown", "value")]
)
def get_driver_profile_section(name):
    driver_data = df_driver_info[df_driver_info['name'] == name]
    full_name = driver_data['name'].values[0]
    date_of_birth = driver_data['dob'].values[0]
    nationality = driver_data['nationality'].values[0]
    season_wins = str(driver_data['season_wins'].values[0])
    race_wins = driver_data['race_wins'].values[0]
    num_podiums = driver_data['num_podiums'].values[0]
    num_poles = driver_data['num_poles'].values[0]
    num_seasons = driver_data['num_seasons'].values[0]

    if name is not None:
        return html.Div(
            [
                html.H4(full_name),
                html.P("Fecha Nacimiento: " + date_of_birth),
                html.P("Nacionalidad: " + nationality),
                html.P("Títulos Mundiales: " + season_wins),
                html.P("Carreras Ganadas: " + str(race_wins)),
                html.P("Podios: " + str(num_podiums)),
                html.P("Poles: " + str(num_poles)),
                html.P("Temporadas Activo: " + str(num_seasons))
            ],
            style={
                "font-size": '80%'
            }
        )
    else:
        raise PreventUpdate


@app.callback(
    Output("driver-yearly-evolution", "figure"), [Input("driver-name-dropdown", "value")]
)
def get_driver_yearly_evolution_callback(name):
    if name is not None:
        df = df_driver_yearly_info[df_driver_yearly_info["name"] == name]

        fig = go.Figure()
        fig.add_trace(go.Bar(x=list(df['year']),
                             y=list(df['wins']),
                             name='Nº Victorias',
                             marker_color='rgb(255,0,0)'
                             ))
        fig.add_trace(go.Bar(x=list(df['year']),
                             y=list(df['num_poles']),
                             name='Nº Poles',
                             marker_color='rgb(255,100,0)'
                             )),
        fig.add_trace(go.Bar(x=list(df['year']),
                             y=list(df['num_podiums']),
                             name='Nº Podios',
                             marker_color='rgb(255,200,0)'
                             ))

        fig.update_layout(title='Evolución del Rendimiento del Conductor',
                          xaxis_title='Año',
                          yaxis_title='Nº')

        return fig

    else:
        raise PreventUpdate
