from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc

from app import app
import pages


def layout():
    return [
        dcc.Location(id="url-eda", refresh=True),
        dbc.Navbar(
            dbc.Container(
                children=[
                    html.A(
                        # Use row and col to control vertical alignment of logo / brand
                        dbc.Row(
                            [
                                dbc.Col(
                                    html.Img(
                                        src=app.get_asset_url("logo.png"), height="30px"
                                    )
                                ),
                                dbc.Col(
                                    dbc.NavbarBrand(
                                        "EDA", className="ml-2"
                                    )
                                ),
                            ],
                            className="ml-auto flex-nowrap mt-3 mt-md-0",
                            align="center",
                        ),
                    ),
                    dbc.Row(
                        children=[
                            dbc.Col(dbc.NavLink("Home", href=app.get_relative_path("/"), style={'color': 'white'})),
                            dbc.Col(dbc.NavLink("Drivers", href=app.get_relative_path("/eda/drivers"), style={'color': 'white'})),
                            dbc.Col(dbc.NavLink("Constructors", href=app.get_relative_path("/eda/constructors"), style={'color': 'white'})),
                            dbc.Col(dbc.NavLink("Circuits", href=app.get_relative_path("/eda/circuits"), style={'color': 'white'})),
                            dbc.Col(dbc.NavLink("Vehicles", href=app.get_relative_path("/eda/vehicles"), style={'color': 'white'})),
                        ],
                        align='center',
                        style={"paddingLeft": "480px"},
                    ),
                ],
            ),
            color='black',
            style={
                'opacity': 0.75
            }

        ),
        html.Div(id="page-content-eda"),
    ]


# [CALLBACK] Navegar entre páginas
@app.callback(Output("page-content-eda", "children"), [Input("url-eda", "pathname")])
def navigate_to_page(pathname):
    path = app.strip_relative_path(pathname)
    if path == "home":
        return None
    if path == "eda/drivers":
        return pages.drivers.layout()
    elif path == "eda/constructors":
        return pages.constructors.layout()
    elif path == "eda/circuits":
        return pages.circuits.layout()
    elif path == "eda/vehicles":
        return pages.vehicles.layout()
    else:
        return "404"
