# Vehicles page: to show 3 graphs. 

import itertools
import plotly.graph_objects as go
import plotly.express as px
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc

from data_reader import *
from app import app

# Fucion pricipal para obteer los análisis de los tiempos filtrando por los años seleccionados
def get_df_analisis_tiempos(years):
    # Extraemos los tiempos de vuelta para cada conductor en cada carrera
    df_analisis_tiempos = tiempos_vuelta[['raceId', 'driverId', 'time', 'milliseconds']]
    # Extraemos el circuito y el año de cada carrera, filtrando por año
    carreras_historico = historico_carreras.copy()[
        historico_carreras['year'].isin(list(range(years[0], years[1] + 1)))]
    df_analisis_tiempos = carreras_historico[['raceId', 'circuitId', 'year']].merge(df_analisis_tiempos)
    # Extraemos la escudería de cada piloto
    df_analisis_tiempos = pd.merge(historico_resultados[['raceId', 'driverId', 'constructorId']], df_analisis_tiempos,
                                   left_on=['raceId', 'driverId'], right_on=['raceId', 'driverId'])
    # Extraemos el nombre abreviado de cada piloto
    df_analisis_tiempos = pd.merge(df_analisis_tiempos, conductores[['driverId', 'code']])
    # Extraemos el nombre de la escudería de cada piloto
    df_analisis_tiempos = pd.merge(df_analisis_tiempos, constructores[['constructorId', 'name']]).rename(
        {'code': 'driver_code', 'name': 'constructor_name'}, axis=1)

    return df_analisis_tiempos


# Función evolución tiempos por vuelta
def get_yearly_evolution_time(years):
    # Dataframe tiempos dependiendo de los años
    df_tiempos = get_df_analisis_tiempos(years)

    # Mejor Tiempo de Vuelta por Carrera
    df_fastest_lap = df_tiempos.groupby(['raceId', 'circuitId', 'year'], as_index=False)['milliseconds'].min()
    # Mejor Tiempo por Circuito cada Año
    df_fastest_lap = df_fastest_lap.groupby(['circuitId', 'year'], as_index=False)['milliseconds'].min()

    # En algunos circuitos no se ha corrido todos los años. De ese modo, para evitar calcular diferencias
    # entre años NO consecutivos, creamos un Dataframe con todas las posibles combinaciones Circuito - Año.

    # Todos los Circuitos Posibles
    circuit_unique = list(df_fastest_lap['circuitId'].unique())
    # Todos los Años con Carreras
    year_unique = list(df_fastest_lap['year'].unique())

    # Todas las posibles combinaciones de circuitos y años
    all_circuits_years = pd.DataFrame(list(itertools.product(circuit_unique, year_unique)),
                                      columns=['circuitId', 'year'])

    # Rellenamos con NaN, los tiempos de vuelta de aquellas combinaciones para las que no tenemos datos
    df_fastest_lap = pd.merge(df_fastest_lap, all_circuits_years, how="outer").sort_values(['circuitId', 'year'])

    # Calculamos la diferencia relative (Relative Delta) entre los tiempos de vuelta de un mismo circuito durante
    # años consecutivos.
    df_fastest_lap['rel_delta'] = df_fastest_lap.groupby(['circuitId'], as_index=False)['milliseconds'].pct_change()

    # Eliminamos los rel_delta nulos
    df_yearly_delta = df_fastest_lap.copy().dropna(inplace=False)

    # Calculamos la media anual del delta relativo
    df_yearly_delta = df_yearly_delta.groupby(["year"], as_index=False)['rel_delta'].mean()

    return df_yearly_delta


# Función evolución tiempos por vuelta consistencia
def get_yearly_mean_time_consistencia_constructor(years):
    # Dataframe tiempos dependiendo de los años
    df_tiempos = get_df_analisis_tiempos(years)

    # Métrica 1 - Consistencia
    df_constructors_consistence = df_tiempos.groupby(['year', 'constructor_name'], as_index=False)[
        'milliseconds'].mean()

    # Label Escudería Más Consistente por año
    df_constructor_consistence_max = df_constructors_consistence.groupby('year', as_index=False).min(
        'milliseconds').merge(df_constructors_consistence).sort_values(['year', 'milliseconds'])
    df_constructors_consistence['label'] = \
        df_constructors_consistence.groupby(['year', 'milliseconds'], as_index=False).min('milliseconds').merge(
            df_constructor_consistence_max, how='outer')['constructor_name']

    return df_constructors_consistence


# Función evolución tiempos por vuelta velocidad
def get_yearly_mean_time_speed_constructor(years):
    # Dataframe tiempos dependiendo de los años
    df_tiempos = get_df_analisis_tiempos(years)

    # Métrica 2 - Rapidez
    df_constructors_speed = df_tiempos.groupby(['year', 'constructor_name'], as_index=False)[
        'milliseconds'].min().sort_values(['year', 'milliseconds'])

    # Label Escudería más rápida por año
    df_constructor_speed_max = df_constructors_speed.groupby('year', as_index=False).min('milliseconds').merge(
        df_constructors_speed).sort_values(['year', 'milliseconds'])
    df_constructors_speed['label'] = \
        df_constructors_speed.groupby(['year', 'milliseconds'], as_index=False).min('milliseconds').merge(
            df_constructor_speed_max, how='outer')['constructor_name']

    return df_constructors_speed


# Definición del layout de esta página
def layout():
    return [
        html.Div
        (
            [
                dbc.Row
                (
                    [
                        # Slider para filtrar por los años deseados.
                        dbc.Label("Years", html_for="years-slider"),
                        dcc.RangeSlider(id="years_variacion_tiempo_vuelta_slider",
                                        min=1997,
                                        max=2022,
                                        step=1,
                                        value=[1997, 2022],
                                        marks={i: str(i) for i in range(1997, 2023)})
                    ],
                    justify="center",
                    align="center",
                    style = {
                        'margin-top': '2.5%',
                        'margin-bottom': '2.5%',
                        'margin-left': '5%',
                        'margin-right': '5%'
                    }
                ),

                dbc.Row
                (
                    [
                        dbc.Card(
                            # Gráfico 1: variación de tiempos por vuelta
                            dcc.Graph
                            (
                                id="variacion_tiempo_vuelta_figure",
                                style={
                                    "display": "block"
                                },
                            ),
                            color = 'danger',
                            outline = True
                        )
                    ],
                    justify="center",
                    align="center",
                    style = {
                        'margin-bottom': '2.5%',
                        'margin-left': '5%',
                        'margin-right': '5%'
                    }
                ),

                dbc.Row
                (
                    [
                        dbc.Card(
                            # Gráfico 2: variación de tiempo por año y constructor para ver la consistencia
                            dcc.Graph
                            (
                                id="variacion_tiempo_year_constructor_consistencia_figure",
                                style={
                                    "display": "block"
                                },
                            ),
                            color = 'danger',
                            outline = True
                        )
                    ],
                    justify="center",
                    align="center",
                    style = {
                        'margin-top': '2.5%',
                        'margin-bottom': '1%',
                        'margin-left': '5%',
                        'margin-right': '5%'
                    }
                ),

                html.P(
                    # Nota aclaratorio a pie de gráfica
                    'NOTA: La etiqueta marcada en ambas gráficas (superior e inferior) corresponde a la escudería con \
                     mejores resultados para cada caso.',
                    id='text_clarify'.format(id),
                    style = {
                        'margin-top': '2.5%',
                        'margin-bottom': '2.5%',
                        'margin-left': '5%',
                        'margin-right': '5%'
                    }
                ),

                dbc.Row
                (
                    [
                        dbc.Card(
                            # Gráfico 3: variación de tiempo por año y constructor para ver la rapidez
                            dcc.Graph
                            (
                                id="variacion_tiempo_year_constructor_rapidez_figure",
                                style={
                                    "display": "block"
                                },
                            ),
                            color = 'danger',
                            outline = True
                        )
                    ],
                    justify="center",
                    align="center",
                    style = {
                        'margin-top': '2.5%',
                        'margin-bottom': '1%',
                        'margin-left': '5%',
                        'margin-right': '5%'
                    }
                ),

                html.P(
                    # Nota aclaratorio a pie de gráfica
                    'NOTA: La etiqueta marcada en ambas gráficas (superior e inferior) corresponde a la escudería con \
                     mejores resultados para cada caso.',
                    id='text_clarify'.format(id),
                    style = {
                        'margin-top': '2.5%',
                        'margin-bottom': '2.5%',
                        'margin-left': '5%',
                        'margin-right': '5%'
                    }
                ),
            ]
        )
    ]


## Cada uno de los tres gráficos pueden ser filtrados por los años deseados. Por ello se necesitan 3 funciones callback

# Callback para el gráfico 1
@app.callback(
    Output("variacion_tiempo_vuelta_figure", "figure"),
    [Input("years_variacion_tiempo_vuelta_slider", "value")]
)
def variacion_tiempo_vuelta(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        fig = go.Figure()

        # Llamada a la fución para obteer el dataset a ser pintado en fución de los años seleccionados
        df_yearly_delta = get_yearly_evolution_time(year_range)

        # Figura variacion tiempo por vuelta
        fig.add_trace(go.Scatter(x=df_yearly_delta['year'], y=df_yearly_delta['rel_delta'] * 100,
                                 mode='lines+markers',
                                 name='lines+markers'))

        fig.update_layout(title='Media de la Variación Relativa Anual en los Tiempos de Vuelta',
                          xaxis_title='Año',
                          yaxis_title='Variación Relativa',
                          yaxis_ticksuffix="%")

        fig.update_traces(marker_color="#c3423f")

        return fig


# Callback para el gráfico 2
@app.callback(
    Output("variacion_tiempo_year_constructor_consistencia_figure", "figure"),
    [Input("years_variacion_tiempo_vuelta_slider", "value")]
)
def variacion_tiempo_year_consistencia_constructor(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        # Llamada a la fución para obteer el dataset a ser pintado en fución de los años seleccionados
        df_constructors_consistence = get_yearly_mean_time_consistencia_constructor(year_range)

        # Gráfica Consistencia Constructores
        fig_consistence = px.scatter(
            data_frame=df_constructors_consistence,
            x='year',
            y='milliseconds',
            color='constructor_name',
            text='label',
            hover_data={'label': False}
        )
        fig_consistence.update_layout(
            title_text=f'Media del Tiempo de Vuelta por Año y Constructor',
        )

        return fig_consistence


# Callback para el gráfico 3
@app.callback(
    Output("variacion_tiempo_year_constructor_rapidez_figure", "figure"),
    [Input("years_variacion_tiempo_vuelta_slider", "value")]
)
def variacion_tiempo_year_rapidez_constructor(year_range):
    if (year_range is None) or (year_range == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        # Llamada a la fución para obteer el dataset a ser pintado en fución de los años seleccionados
        df_constructors_speed = get_yearly_mean_time_speed_constructor(year_range)

        # Gráfica Rapidez Constructores
        fig_rapidez = px.scatter(
            data_frame=df_constructors_speed,
            x='year',
            y='milliseconds',
            color='constructor_name',
            text='label',
            hover_data={'label': False}
        )
        fig_rapidez.update_layout(
            title_text=f'Vueltas Rápida por Año y Escudería',
        )

        return fig_rapidez
