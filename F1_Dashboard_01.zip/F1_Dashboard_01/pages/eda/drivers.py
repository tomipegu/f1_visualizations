# Drivers principal page: to navigate between the two possible pages (general information and driver statistics)

from dash import html, Input, Output
import dash_bootstrap_components as dbc
import pages
from app import app


# Defiimos el layout de la págia
def layout():
    return [
        html.Div(
            [
                dbc.Row(
                    [
                        # Creación de dos botones para elegir entre dos pestañas: información general y estadísticas individualizadas de los pilotos.
                        dbc.ButtonGroup(
                            [
                                dbc.Button("General", id="btn-general-drivers", outline=True, color="primary", active=True, n_clicks_timestamp=0),
                                dbc.Button("Driver Stats", id="btn-stats-drivers", outline=True, color="primary", n_clicks_timestamp=0),
                            ],
                            size='sm',
                            style={
                                'width': '15%',
                                'margin': 'auto',
                                'margin-top': '1.5%'
                            }
                        )
                    ]
                )
            ]
        ),
        html.Div(id="drivers-page-content")
    ]


# Callback co la lógica de la navegación entre las pestañas dentro de la categoría conductores
@app.callback(
    [Output("drivers-page-content", "children"),
     Output("btn-general-drivers", "active"),
     Output("btn-stats-drivers", "active")],     
    [Input('btn-general-drivers', 'n_clicks_timestamp'),
     Input('btn-stats-drivers', 'n_clicks_timestamp')])
def on_click(ts_btn_general, ts_btn_stats):
    if (ts_btn_general is None) | (ts_btn_stats is None): 
        return pages.drivers_general.layout(), True, False
    elif ts_btn_general > ts_btn_stats:
        return pages.drivers_general.layout(), True, False
    elif ts_btn_stats > ts_btn_general:
        return pages.drivers_stats.layout(), False, True
    else:
        return pages.drivers_general.layout(), True, False
