# Home/landig page

import dash
from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc

from app import app

def layout():
    return [
        html.Div(
            [
                dbc.Row(
                    [
                        dbc.Col([
                                html.Img(
                                    src=app.get_asset_url("logo.png"), 
                                    height="40px",
                                    style = {'margin-top':'3%', 'margin-left':'2.5%'}
                                ),
                            ]
                        )
                    ],
                    style={
                        'background-color': 'black',
                        'height': '15%'
                    }

                ),
                dbc.Row(
                    [
                        dbc.Col(width=3, style={'textAlign': 'center', 'color':'white'}),
                        dbc.Col(
                            html.Div(
                                [
                                    html.H2("F1 Team Builder", className="display-3", style={'color': 'white', 'textAlign':'center'}),
                                    html.Hr(className="my-2", style={'background-color':'red', 'height':'3px', 'width':'72.5%', 'opacity':'0.9', 'margin':'auto'}),
                                    html.H3(
                                        "Want to become the next champion?",
                                        style = {'color': 'white', 'margin-left': '13.75%'}
                                    ),
                                ],
                                className="h-100 p-5",
                            ),
                            md=6, 
                            width = 6,
                        ),
                        dbc.Col([        
                                dbc.Nav([
                                        dbc.Card(
                                            [
                                                dbc.Row(
                                                    [
                                                        dbc.Col(html.H3(u"\u2022"), style={'textAlign': 'right', 'color':'yellow'}, width=1),
                                                        dbc.Col(html.H6(dbc.NavLink("EDA", href="/eda/drivers", style={'textAlign': 'left', 'color':'white'})), width = 9)
                                                    ],
                                                    style = {'margin': 'auto', 'margin-left': '5%', 'margin-right': '0%'}
                                                    
                                                )
                                                
                                            ],
                                            style = {'height':'8.5vh','border-color': 'rgba(255, 255 ,51, 0.30)', 'background-color': 'rgba(0, 0 ,0, 1)', 'margin-left': '15%', 'margin-right': '15%', 'margin-bottom': '0.75%'}
                                        ),
                                        dbc.Card(
                                            [
                                                dbc.Row(
                                                    [
                                                        dbc.Col(html.H3(u"\u2022"), style={'textAlign': 'right', 'color':'yellow'}, width=1),
                                                        dbc.Col(html.H6(dbc.NavLink("Clustering", href="/clustering/preprocessing", style={'textAlign': 'left', 'color':'white'})), width = 9)
                                                    ],
                                                    style = {'margin': 'auto', 'margin-left': '5%', 'margin-right': '0%'}
                                                    
                                                )
                                                
                                            ],
                                            style = {'height':'8.5vh','border-color': 'rgba(255, 255 ,51, 0.30)', 'background-color': 'rgba(0, 0 ,0, 1)','margin-left': '15%', 'margin-right': '15%', 'margin-bottom': '0.75%'}
                                        ),
                                        dbc.Card(
                                            [
                                                dbc.Row(
                                                    [
                                                        dbc.Col(html.H3(u"\u2022"), style={'textAlign': 'right', 'color':'yellow'}, width=1),
                                                        dbc.Col(html.H6(dbc.NavLink("The Team", href="/team", style={'textAlign': 'left', 'color':'white'})), width = 9)
                                                    ],
                                                    style = {'margin': 'auto', 'margin-left': '5%', 'margin-right': '0%'}
                                                    
                                                )
                                                
                                            ],
                                            style = {'height':'8.5vh','border-color': 'rgba(255, 255 ,51, 0.30)', 'background-color': 'rgba(0, 0 ,0, 1)','margin-left': '15%', 'margin-right': '15%'}
                                        )
                                    ],
                                    vertical=True,
                                    pills=True,
                                )
                            ],
                            width=3, 
                        )
                    ],
                    align="center",
                    justify="center",
                    style={"height": "80vh"},  
                ),

            ],
            className="pad-row",
            style = {
                "background-image": "url(assets/home_background.jpg)",
                'background-size': '100%',
                'position': 'fixed',
                'width': '100%',
                'height': '100%',
                'background-position': 'center',
                'background-repeat': 'no-repeat',
                'background-size': 'cover',
                'opacity': 0.75
            }
        ),
    ]