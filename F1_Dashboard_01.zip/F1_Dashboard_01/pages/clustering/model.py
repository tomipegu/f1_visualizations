from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
import plotly.express as px
from sklearn.preprocessing import StandardScaler

from model_data_reader import *
from app import app


def get_data_ready_for_radar():
    # Keep the cluster of each row y drop some variables that are not relevant for the visualizations
    cluster_column = best_model_df["cluster"]
    best_model_df_main_variables = best_model_df.drop(
        ["race_year", "raceId", "driverId", "constructorId", "cluster", "code"], axis=1)

    # Due to the magnitude difference among variables, let's normalize the results and add the cluster column
    best_model_df_normalized = (best_model_df_main_variables - best_model_df_main_variables.min()) / (
            best_model_df_main_variables.max() - best_model_df_main_variables.min())
    best_model_df_normalized['cluster'] = cluster_column

    return best_model_df_normalized


def get_radar_mean(start_position, driver_points, age, percentage_points, positions_gain, constructor_points, race_status, fastest_lap_rank, final_position):
    best_model_df_normalized = get_data_ready_for_radar()

    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['start_position'] >= start_position[0]) & (best_model_df_normalized['start_position'] <= start_position[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['driver_points'] >= driver_points[0]) & (best_model_df_normalized['driver_points'] <= driver_points[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['age'] >= age[0]) & (best_model_df_normalized['age'] <= age[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['percentage_points'] >= percentage_points[0]) & (best_model_df_normalized['percentage_points'] <= percentage_points[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['positions_gain'] >= positions_gain[0]) & (best_model_df_normalized['positions_gain'] <= positions_gain[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['constructor_points'] >= constructor_points[0]) & (best_model_df_normalized['constructor_points'] <= constructor_points[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['race_status'] >= race_status[0]) & (best_model_df_normalized['race_status'] <= race_status[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['fastest_lap_rank'] >= fastest_lap_rank[0]) & (best_model_df_normalized['fastest_lap_rank'] <= fastest_lap_rank[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['final_position'] >= final_position[0]) & (best_model_df_normalized['final_position'] <= final_position[1])]

    # Get the mean values of the variables for each cluster
    cluster_0 = best_model_df_normalized[(best_model_df_normalized['cluster'] == 0)].mean(axis=0).drop("cluster")
    cluster_1 = best_model_df_normalized[(best_model_df_normalized['cluster'] == 1)].mean(axis=0).drop("cluster")
    cluster_2 = best_model_df_normalized[(best_model_df_normalized['cluster'] == 2)].mean(axis=0).drop("cluster")
    cluster_3 = best_model_df_normalized[(best_model_df_normalized['cluster'] == 3)].mean(axis=0).drop("cluster")
    cluster_4 = best_model_df_normalized[(best_model_df_normalized['cluster'] == 4)].mean(axis=0).drop("cluster")

    return cluster_0, cluster_1, cluster_2, cluster_3, cluster_4


def get_radar_median(start_position, driver_points, age, percentage_points, positions_gain, constructor_points, race_status, fastest_lap_rank, final_position):
    best_model_df_normalized = get_data_ready_for_radar()

    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['start_position'] >= start_position[0]) & (best_model_df_normalized['start_position'] <= start_position[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['driver_points'] >= driver_points[0]) & (best_model_df_normalized['driver_points'] <= driver_points[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['age'] >= age[0]) & (best_model_df_normalized['age'] <= age[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['percentage_points'] >= percentage_points[0]) & (best_model_df_normalized['percentage_points'] <= percentage_points[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['positions_gain'] >= positions_gain[0]) & (best_model_df_normalized['positions_gain'] <= positions_gain[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['constructor_points'] >= constructor_points[0]) & (best_model_df_normalized['constructor_points'] <= constructor_points[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['race_status'] >= race_status[0]) & (best_model_df_normalized['race_status'] <= race_status[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['fastest_lap_rank'] >= fastest_lap_rank[0]) & (best_model_df_normalized['fastest_lap_rank'] <= fastest_lap_rank[1])]
    best_model_df_normalized = best_model_df_normalized[(best_model_df_normalized['final_position'] >= final_position[0]) & (best_model_df_normalized['final_position'] <= final_position[1])]

    # Get the median values of the variables for each cluster
    cluster_0_median = best_model_df_normalized[(best_model_df_normalized['cluster'] == 0)].median(axis=0).drop(
        "cluster")
    cluster_1_median = best_model_df_normalized[(best_model_df_normalized['cluster'] == 1)].median(axis=0).drop(
        "cluster")
    cluster_2_median = best_model_df_normalized[(best_model_df_normalized['cluster'] == 2)].median(axis=0).drop(
        "cluster")
    cluster_3_median = best_model_df_normalized[(best_model_df_normalized['cluster'] == 3)].median(axis=0).drop(
        "cluster")
    cluster_4_median = best_model_df_normalized[(best_model_df_normalized['cluster'] == 4)].median(axis=0).drop(
        "cluster")

    return cluster_0_median, cluster_1_median, cluster_2_median, cluster_3_median, cluster_4_median


def get_characteristics_clusters():
    # Let's recap the best model and add the columns to the dataframe

    best_model = best_model_df.drop("code", axis = 1)

    scaler = StandardScaler()
    x_std = scaler.fit_transform(best_model)

    x_std = pd.DataFrame(x_std, columns=best_model.columns)

    # Let's now just take the three variables used in the model and normalize them.
    cluster_column = best_model["cluster"]

    best_model_df_variables_model = best_model.drop(
        ["race_year", "raceId", "driverId", "constructorId", "age", "final_position", "driver_points", "start_position",
         "race_status", "constructor_points", "cluster"], axis=1)
    best_model_df_variables_model = (best_model_df_variables_model - best_model_df_variables_model.min()) / (
            best_model_df_variables_model.max() - best_model_df_variables_model.min())
    best_model_df_variables_model["cluster"] = cluster_column

    x_mean = pd.concat([pd.DataFrame(best_model_df_variables_model.mean().drop('cluster'), columns=['mean']),
                        best_model_df_variables_model.groupby('cluster').mean().T], axis=1)

    x_dev_rel = x_mean.apply(lambda x: round((x - x['mean']) / x['mean'], 2) * 100, axis=1)
    x_dev_rel.drop(columns=['mean'], inplace=True)
    x_mean.drop(columns=['mean'], inplace=True)
    x_std_mean = pd.concat([pd.DataFrame(x_std.mean(), columns=['mean']),
                            x_std.mean().T], axis=1)

    x_std_dev_rel = x_std_mean.apply(lambda x: round((x - x['mean']) / x['mean'], 2) * 100, axis=1)
    x_std_dev_rel.drop(columns=['mean'], inplace=True)
    x_std_mean.drop(columns=['mean'], inplace=True)

    df = pd.DataFrame(x_dev_rel.T)

    return df

# [FUNCION]
def characteristics_clusters_figure():
    df = get_characteristics_clusters()

    fig = px.bar(df,
                    x=df.index,
                    y=["fastest_lap_rank", "positions_gain", "percentage_points"],
                    barmode='group')
    fig.update_layout(title="Características de los diferentes clusters obtenidos",
                        yaxis_title="Desviación en % con respecto a la media",
                        xaxis_title="Número de cluster")

    return fig


def layout():
    return [
        html.Div
        (
            [
                dbc.Row(
                    [

                        dbc.Col(
                            [   
                                dbc.Label("Start Position", html_for="range-slider"),
                                dcc.RangeSlider(id="start-position-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Driver Points", html_for="range-slider"),
                                dcc.RangeSlider(id="driver-points-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Age", html_for="range-slider"),
                                dcc.RangeSlider(id="age-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Percentage Points", html_for="range-slider"),
                                dcc.RangeSlider(id="percentage-points-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Positions Gain", html_for="range-slider"),
                                dcc.RangeSlider(id="positions-gain-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Constructor Points", html_for="range-slider"),
                                dcc.RangeSlider(id="constructor-points-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Race Status", html_for="range-slider"),
                                dcc.RangeSlider(id="race-status-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Fastest Lap Rank", html_for="range-slider"),
                                dcc.RangeSlider(id="fastest-lap-rank-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),

                                dbc.Label("Final Position", html_for="range-slider"),
                                dcc.RangeSlider(id="final-position-range-slider",
                                    min=0,
                                    max=1,
                                    step=0.1,
                                    value=[0,1],
                                    marks = None),
                            ],
                            width=2,
                            style = {
                                'margin-top': '2.5%',
                                'margin-bottom': '2.5%',
                                'margin-left': '2.5%',
                                'margin-right':'2.5%'
                            }
                        ),

                        dbc.Col(
                            [
                                dbc.Row
                                (
                                    [
                                        dbc.Col
                                        (
                                            [
                                                dbc.Card(
                                                    dcc.Graph
                                                    (
                                                        id="radar_mean_figure",
                                                        style={
                                                            "display": "block"
                                                        },
                                                    ),
                                                    color = 'danger',
                                                    outline = True
                                                )
                                            ],
                                            width=6
                                        ),
                                        dbc.Col
                                        (
                                            [
                                                dbc.Card(
                                                    dcc.Graph
                                                    (
                                                        id="radar_median_figure",
                                                        style={
                                                            "display": "block"
                                                        },
                                                    ), 
                                                    color = 'danger',
                                                    outline = True,
                                                ),
                                              
                                            ],
                                            width=6
                                        )
                                    ],
                                    justify="center",
                                    align="center",
                                    style = {
                                        'margin-top': '2.5%',
                                        'margin-bottom': '2.5%',
                                    }
                                ),

                                dbc.Row
                                (
                                    [
                                        dbc.Card(
                                            dcc.Graph
                                            (
                                                id="characteristics_clusters_figure",
                                                style={
                                                    "display": "block"
                                                },
                                                figure = characteristics_clusters_figure()
                                            ),
                                            color = 'danger',
                                            outline = True
                                        ),
                                    ],
                                    style = {
                                        'margin-bottom': '2.5%',
                                    }
                                )
                            ],
                            width = 9
                        )
                    ]
                )
            ]
        )
    ]


@app.callback(
    Output("radar_mean_figure", "figure"),
    [Input("start-position-range-slider", "value"),
     Input("driver-points-range-slider", "value"),
     Input("age-range-slider", "value"),
     Input("percentage-points-range-slider", "value"),
     Input("positions-gain-range-slider", "value"),
     Input("constructor-points-range-slider", "value"),
     Input("race-status-range-slider", "value"),
     Input("fastest-lap-rank-range-slider", "value"),
     Input("final-position-range-slider", "value")
    ]
)
def radar_mean(start_position, driver_points, age, percentage_points, positions_gain, constructor_points, race_status, fastest_lap_rank, final_position):
    if (start_position is None) or (start_position == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        # Plot the radar plot for mean values
        categories = ['age', 'driver_points', 'start_position', 'final_position', 'fastest_lap_rank', 'race_status',
                      'constructor_points', 'positions_gain', 'percentage_points']

        cluster0, cluster1, cluster2, cluster3, cluster4 = get_radar_mean(start_position, driver_points, age, percentage_points, positions_gain, constructor_points, race_status, fastest_lap_rank, final_position)

        fig = go.Figure()

        fig.add_trace(go.Scatterpolar(
            r=cluster0,
            theta=categories,
            fill='toself',
            name='Cluster 0'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster1,
            theta=categories,
            fill='toself',
            name='Cluster 1'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster2,
            theta=categories,
            fill='toself',
            name='Cluster 2'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster3,
            theta=categories,
            fill='toself',
            name='Cluster 3'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster4,
            theta=categories,
            fill='toself',
            name='Cluster 4'
        ))

        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=False,
                    range=[0, 1]
                )),
            title="Clusters - Métrica: Media",
            showlegend=True
        )

    return fig


@app.callback(
    Output("radar_median_figure", "figure"),
    [Input("start-position-range-slider", "value"),
     Input("driver-points-range-slider", "value"),
     Input("age-range-slider", "value"),
     Input("percentage-points-range-slider", "value"),
     Input("positions-gain-range-slider", "value"),
     Input("constructor-points-range-slider", "value"),
     Input("race-status-range-slider", "value"),
     Input("fastest-lap-rank-range-slider", "value"),
     Input("final-position-range-slider", "value")
    ]
)
def radar_median(start_position, driver_points, age, percentage_points, positions_gain, constructor_points, race_status, fastest_lap_rank, final_position):
    if (start_position is None) or (start_position == []):
        return go.Figure(data=[], layout={}), {"display": "none"}
    else:
        # Plot the radar plot for median values
        categories = ['age', 'driver_points', 'start_position', 'final_position', 'fastest_lap_rank', 'race_status',
                      'constructor_points', 'positions_gain', 'percentage_points']

        cluster_0_median, cluster_1_median, cluster_2_median, cluster_3_median, cluster_4_median = get_radar_median(start_position, driver_points, age, percentage_points, positions_gain, constructor_points, race_status, fastest_lap_rank, final_position)

        fig = go.Figure()

        fig.add_trace(go.Scatterpolar(
            r=cluster_0_median,
            theta=categories,
            fill='toself',
            name='Cluster 0'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster_1_median,
            theta=categories,
            fill='toself',
            name='Cluster 1'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster_2_median,
            theta=categories,
            fill='toself',
            name='Cluster 2'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster_3_median,
            theta=categories,
            fill='toself',
            name='Cluster 3'
        ))
        fig.add_trace(go.Scatterpolar(
            r=cluster_4_median,
            theta=categories,
            fill='toself',
            name='Cluster 4'
        ))

        fig.update_layout(
            polar=dict(
                radialaxis=dict(
                    visible=False,
                    range=[0, 1]
                )),
            title="Clusters - Métrica: Mediana",
            showlegend=True
        )

    return fig


