import plotly.graph_objects as go
import plotly.express as px
from dash import dcc, html, Input, Output, dash_table
import dash_bootstrap_components as dbc

from model_data_reader import *
from app import app

# [FUNCION] Bar plot valores nulos antes preprocesado
def get_null_values_before_preprocessing():
    fig = px.bar(df_null_values, y="Variable", x="Null Count", orientation='h')
    fig.update_layout(title='Valores nulos antes del preprocesado',
        xaxis_title='Nº Valores Nulos',
        yaxis_title='Variable')
    return fig

# [FUNCION] Obtener resumen de datos antes preprocesado
def get_data_summary_before_preprocessing():
    df = df_data_summary_before_preprocessing
    return dash_table.DataTable(
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict("records"),
        page_current=0,
        style_header={"backgroundColor": "white", "fontWeight": "bold"},
        style_cell={"textAlign": "center"},
        style_cell_conditional=[
            {"if": {"column_id": "Finished"}, "textAlign": "center"}
        ],
        style_as_list_view=True,
    )

# [FUNCION] Bar plot valores nulos depues preprocesado
def get_null_values_after_preprocessing():
    fig = px.bar(df_null_values_after, y="Variable", x="Null Count", orientation='h')
    fig.update_layout(title='Valores nulos depués del preprocesado',
        xaxis_title='Nº Valores Nulos',
        yaxis_title='Variable')
    return fig

# [FUNCION] Obtener resumen de datos despues preprocesado
def get_data_summary_after_preprocessing():
    df = df_data_summary_after_preprocessing
    return dash_table.DataTable(
        columns=[{"name": i, "id": i} for i in df.columns],
        data=df.to_dict("records"),
        page_current=0,
        style_header={"backgroundColor": "white", "fontWeight": "bold"},
        style_cell={"textAlign": "center"},
        style_cell_conditional=[
            {"if": {"column_id": "Finished"}, "textAlign": "center"}
        ],
        style_as_list_view=True,
    )



def layout():
    return [
        dbc.Container(
            [
                dbc.Tabs(
                    [
                        dbc.Tab(label="Before", tab_id="before-tab"),
                        dbc.Tab(label="After", tab_id="after-tab"),
                    ],
                    id="preprocessing-tabs",
                    active_tab="before-tab",
                ),
                html.Div(id="preprocessing-tab-content", className="p-4"),
            ]
        )
    ]

@app.callback(
    Output("preprocessing-tab-content", "children"),
    [Input("preprocessing-tabs", "active_tab")],
)
def render_tab_content_callback(active_tab):
    """
    This callback takes the 'active_tab' property as input, as well as the
    stored graphs, and renders the tab content depending on what the value of
    'active_tab' is.
    """
    if active_tab is not None:
        if active_tab == "before-tab":
            return [
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dcc.Graph(
                                    id="before-null_values",
                                    style={
                                        "display": "block"
                                    },
                                    figure = get_null_values_before_preprocessing()
                                )
                            ],
                            width = 8
                        )
                    ]
                ),

                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Card(
                                    dbc.CardBody(
                                        [
                                            dbc.CardHeader('Data Summary'),
                                            html.Div(
                                                children = [
                                                    get_data_summary_before_preprocessing()
                                                ]           
                                            )
                                        ]
                                    )
                                )
                            ],
                            width = 12
                        )
                    ]
                )
            ]

        elif active_tab == "after-tab":
            return [
                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dcc.Graph(
                                    id="after-null_values",
                                    style={
                                        "display": "block"
                                    },
                                    figure = get_null_values_after_preprocessing()
                                )
                            ],
                            width = 8
                        )
                    ]
                ),

                dbc.Row(
                    [
                        dbc.Col(
                            [
                                dbc.Card(
                                    dbc.CardBody(
                                        [
                                            dbc.CardHeader('Data Summary'),
                                            html.Div(
                                                children = [
                                                    get_data_summary_after_preprocessing()
                                                ],      
                                            )
                                        ]
                                    )
                                )
                            ],
                            width = 12
                        )
                    ]
                )
            ]

    return "No tab selected"