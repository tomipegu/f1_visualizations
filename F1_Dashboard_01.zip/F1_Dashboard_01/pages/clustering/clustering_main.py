from dash import dcc, html, Input, Output
import dash_bootstrap_components as dbc

from app import app
import pages


def layout():
    return [
        dcc.Location(id="url-clustering", refresh=True),
        dbc.Navbar(
            dbc.Container(
                children=[
                    html.A(
                        # Use row and col to control vertical alignment of logo / brand
                        dbc.Row(
                            [
                                dbc.Col(
                                    html.Img(
                                        src=app.get_asset_url("logo.png"), height="30px"
                                    )
                                ),
                                dbc.Col(
                                    dbc.NavbarBrand(
                                        "EDA", className="ml-2"
                                    )
                                ),
                            ],
                            className="ml-auto flex-nowrap mt-3 mt-md-0",
                            align="center",
                        ),
                    ),
                    dbc.Row(
                        children=[
                            dbc.Col(dbc.NavLink("Home", href=app.get_relative_path("/"), style={'color': 'white'})),
                            dbc.Col(dbc.NavLink("Preprocessing", href=app.get_relative_path("/clustering/preprocessing"),
                                                style={'color': 'white'})),
                            dbc.Col(dbc.NavLink("Model", href=app.get_relative_path("/clustering/model"),
                                                style={'color': 'white'})),
                        ],
                        align='center',
                        style={"paddingLeft": "550px"},
                    ),
                ],
            ),
            color='black',
            style={
                'opacity': 0.75
            }

        ),
        html.Div(id="page-content-clustering"),
    ]


# [CALLBACK] Navegar entre páginas
@app.callback(Output("page-content-clustering", "children"), [Input("url-clustering", "pathname")])
def navigate_to_page(pathname):
    path = app.strip_relative_path(pathname)
    if path == "home":
        return None
    if path == "clustering/preprocessing":
        return pages.preprocessing.layout()
    elif path == "clustering/model":
        return pages.model.layout()
    else:
        return "404"
