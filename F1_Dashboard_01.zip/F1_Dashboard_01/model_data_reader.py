# Page for readig the data, doing the calculations, preprocess of the data... for the clustering model

# ============
# LIBRERÍAS #
# ============
import joblib
import pandas as pd
import numpy as np

# ==============
# CARGA DATOS #
# ==============

# Circuitos
circuitos = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/circuits.csv")
# Resultados Constructores
resultados_constructores = pd.read_csv(
    "https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/constructor_results.csv")
# Standings Constructores
standing_constructores = pd.read_csv(
    "https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/constructor_standings.csv")
# Constructores
constructores = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/constructors.csv")
# Standings Conductores
standing_conductores = pd.read_csv(
    "https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/driver_standings.csv")
# Conductores
conductores = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/drivers.csv")
# Tiempos de Vuelta
tiempos_vuelta = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/lap_times.csv")
# Pit-Stops
pit_stops = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/pit_stops.csv")
# Histórico Qualifying
historico_clasificacion = pd.read_csv(
    "https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/qualifying.csv")
# Histórico Carreras
historico_carreras = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/races.csv")
# Historico Resultados
historico_resultados = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/results.csv")
# Histórico Temporadas
historico_temporadas = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/seasons.csv")
# Historico Carreras Sprint
historico_sprint = pd.read_csv(
    "https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/sprint_results.csv")
# Glosario Estados de Carrera (finalizado, retirado, avería, etc.)
estados_carrera = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/status.csv")

# ============== #
# DATASET MODELO #
# ============== #

# Fechas Carreras
fechas_carreras = historico_carreras.copy()[['raceId', 'date', 'year']]
fechas_carreras.rename(columns={'date': 'race_date', 'year': 'race_year'}, inplace=True)

# Conductores
conductores_reduced = conductores.copy()[['driverId', 'dob', 'nationality']]

# Resultados Constructores
resultados_constructores_reduced = resultados_constructores.copy()[['constructorId', 'raceId', 'points']]
resultados_constructores_reduced.rename(columns={'points': 'constructor_points'}, inplace=True)

# Resultados Carreras
resultados_carreras_reduced = historico_resultados.copy()[
    ['raceId', 'driverId', 'constructorId', 'points', 'grid', 'position', 'rank', 'statusId']]
resultados_carreras_reduced.rename(
    columns={'points': 'driver_points', 'grid': 'start_position', 'position': 'final_position',
             'rank': 'fastest_lap_rank'}, inplace=True)

# Status Carreras
estados_carreras_reduced = estados_carrera.copy()

# Clasificación de los posibles estados de carrera
status_conditions = [
    (estados_carreras_reduced['statusId'] == 1),
    (estados_carreras_reduced['statusId'] > 1) & (estados_carreras_reduced['statusId'] <= 4),
    (estados_carreras_reduced['statusId'] > 4)
]
status_values = ['Finished', 'Pilot Error', 'Vehicle Error']
estados_carreras_reduced['race_status'] = np.select(status_conditions, status_values)

# Eliminamos las categorías antiguas
estados_carreras_reduced = estados_carreras_reduced.drop('status', axis=1)

# Dataset Modelo
dataset_reduced = conductores_reduced.merge(resultados_carreras_reduced, on='driverId', how='left') \
    .merge(resultados_constructores_reduced, on=['raceId', 'constructorId'], how='left') \
    .merge(estados_carreras_reduced, on=['statusId'], how='left') \
    .merge(fechas_carreras, on='raceId', how='left')

# Edad Conductores
dataset_reduced['dob'] = dataset_reduced.apply(
    lambda row: int(((pd.to_datetime(row['race_date']) - pd.to_datetime(row['dob'])).days / 365.2)), axis=1)
dataset_reduced.rename(columns={"dob": "age"}, inplace=True)

# Nos quedamos solo con las columnas relevantes
dataset_reduced_columns = ['driverId', 'age', 'nationality', 'raceId', 'constructorId', 'driver_points',
                           'start_position', 'final_position', 'fastest_lap_rank', 'constructor_points', 'race_status',
                           'race_year']
dataset_reduced = dataset_reduced[dataset_reduced_columns]

# Eliminamos todas las observaciones anteriores a 1997
dataset_reduced = dataset_reduced[dataset_reduced['race_year'] >= 1997]

# ============ #
# PREPROCESADO #
# ============ #

# Tipología de las variables
############################

# Tipología variables antes del preprocesado
df_tipologia_variables_antes_preprocesado = pd.DataFrame(dataset_reduced.dtypes).reset_index()
df_tipologia_variables_antes_preprocesado.columns = ['Variable', 'Tipologia']

# Aquellos valores que contengan '\\N' los consideramos como nulos
dataset_reduced.loc[dataset_reduced["final_position"] == "\\N", "final_position"] = None
dataset_reduced.loc[dataset_reduced["fastest_lap_rank"] == "\\N", 'fastest_lap_rank'] = None

# Convertimos la Posición Final y el Ranking de Vuelta Rápida a Int
dataset_reduced = dataset_reduced.copy().astype({'final_position': 'float', 'fastest_lap_rank': 'float'})
dataset_reduced = dataset_reduced.copy().astype({'final_position': 'Int64', 'fastest_lap_rank': 'Int64'})

# Valores nulos
###############

# Comprobación valores nulos
df_null_values = pd.DataFrame(dataset_reduced.isna().sum().sort_values(ascending=False)).reset_index()
df_null_values.columns = ['Variable', 'Null Count']
df_null_values = df_null_values[df_null_values['Null Count'] > 0]

"""
Se estudian con más detalle estas tres variables que contienen valores nulos
"""

# Valores nulos en 'constructor_points'
dataset_reduced[dataset_reduced['constructor_points'].isna()].sort_values('age')

"""
Las únicas dos observaciones que cuentan con valores nulos en "constructor_points", corresponden con dos pilotos 
de la misma escudería (HRT) que no clasificaron para competir en el GP Australia 2012. Como no comenzaron la carrera, 
hemos decidido eliminarlos.
"""

# Eliminamos aquellas observaciones cuyo valor "constructor_points" sea nulo
dataset_reduced = dataset_reduced[dataset_reduced["constructor_points"].notna()]

"""
Los valores nulos en las categorías "fastest_lap_rank" y "final_position" corresponden con pilotos que no han podido 
completar una carrera. 
Sin embargo, en el caso de "fastest_lap_rank", es posible que el piloto haya podido dar varias vueltas al circuito y 
su vuelta rápida hay quedado registrada en el sistema, de modo que ese valor no sea nulo. Esta es la razón de que 
haya más valores nulos en una categoría que en la otra.
De modo que podamos analizar todos estos casos de forma igualitaria y sin pérdida de información, vamos a sustituir 
todos los valores nulos como si hubieran quedado últimos en dichas categorías.
"""

# Calculamos el número de pilotos por carrera
num_pilots_per_race = dataset_reduced.groupby('raceId', as_index=False)['driverId'].count()
num_pilots_per_race.rename(columns={'driverId': 'num_pilots'}, inplace=True)

# Asumimos que todos los valores nulos en 'final_position' o 'fastest_lap_rank' equivalen a quedar últimos en esas
# categorías
dataset_reduced['final_position'] = dataset_reduced.apply(
    lambda row: num_pilots_per_race[num_pilots_per_race['raceId'] == row['raceId']]['num_pilots'].values[0] if (
        pd.isna(row['final_position'])) else row['final_position'], axis=1)
dataset_reduced['fastest_lap_rank'] = dataset_reduced.apply(
    lambda row: num_pilots_per_race[num_pilots_per_race['raceId'] == row['raceId']]['num_pilots'].values[0] if (
        pd.isna(row['fastest_lap_rank'])) else row['fastest_lap_rank'], axis=1)

dataset_reduced.isna().sum()

# Data Summary
##############

# Extraemos un resumen de los datos para detectar anomalías
df_data_summary_before_preprocessing = dataset_reduced.describe().reset_index().round(2)
df_data_summary_before_preprocessing.rename(columns = {'index': 'measure'}, inplace=True)

"""
Observaciones:

*   **driver_points**: si la puntuación máxima por carrera es 26 (ganador de la carrera + vuelta rápida), 
        ¿cómo es posible que el máximo registrado sea de 50?
*   **constructor_points**: si la puntuación máxima de una escudería por carrera es 44 (conductores 1º 25 puntos y 
        2º 18 puntos + vuelta rápida), ¿cómo es posible que el máximo registrado sea 66?
*   **start_position**: ¿comó es posible que la posición inicial mínima sea 0?

Nota: Desde 2019, a parte de la puntuación máxima por posición en carrera (puesto 1º - 25 puntos), 
el ganador de la vuelta rápida en carrera (siempre y cuando haya acabado en el Top 10) se lleva un punto extra.

Comprobación Posición Inicial
"""


"""
Los pilotos que tienen una posición inicial de 0, corresponde con los casos en los que hubo penalizaciones 
(su tiempo de clasificación se anuló) y empezaron al final de la parilla o desde el pit-lane. 
Vamos a tratarlos a todos estos como si hubieran empezado últimos.
"""

dataset_reduced['start_position'] = dataset_reduced.apply(
    lambda row: num_pilots_per_race[num_pilots_per_race['raceId'] == row['raceId']]['num_pilots'].values[0] if (
                row['start_position'] == 0) else row['start_position'], axis=1)

"""
Comprobación Puntuación Conductores
Límite de puntos
"""

# Comprobamos la puntuación de los conductores para aquellos casos donde se superan los límites
dataset_reduced[dataset_reduced['driver_points'] > 26].sort_values(['race_year', 'raceId'])

"""
Hay 3 observaciones en las que el número de puntos se sale de los límites.
Esto se debe a que en la carrera de cierre de campeonato de 2014, el GP Abu Dabi 2014, se estableció un sistema de 
puntuaje doble. De ese modo, solo en esta carrera, las puntuaciones corresponden con el doble que en una carrera normal.
Por ello, podemos concluir que no se trata de un error en la recolección de los datos, sino un cambio en el reglamento 
de la competición.

Homogeneidad en el reparto de puntos

Con el objetivo de detectar más anomalías vamos a proceder a realizar un estudio mas detallado de los sistemas de
puntuación de la F1.
"""

# En vista de las anomalías, comprobamos si el resto de resultados son homogéneos.
# Suma de puntos totales otorgados por carrera
total_points_per_race = dataset_reduced.groupby(['raceId', 'race_year'], as_index=False).sum('driver_points')
total_points_per_race.rename(columns={'driver_points': 'total_driver_points'}, inplace=True)

"""
Podemos empezar a observar, que el número total de puntos por carrera **no es fijo**.
"""

# Posibles Variaciones en la cantidad de puntos totales otorgados por carrera
list(total_points_per_race.sort_values('total_driver_points')['total_driver_points'].unique())

"""
Como podemos observar, existe una gran diferencia entre la cantidad de puntos otorgados entre unas carreras y 
otras. Procedemos a analizar cada caso.
"""

"""
**Conclusiones del análisis de puntuaciones:**
Tras el análisis de las puntuaciones, podemos concluir que no se trata de un error en la colecta de datos, si no que 
las diferencias corresponden con la evolución del reglamento a lo largo de los años.
Dado que nuestro objetivo es realizar un cluster de pilotos de cara a la temporada que viene, es importante que 
apliquemos el reglamento vigente. 
Por esa razón:
* Vamos a eliminar las dos competiciones en las que se corrió menos del 75% de la carrera, junto al polémico GP de 
Estados Unidos de 2005. Consideramos que estos casos pueden introducir ruido en el modelo.
* Vamos a proceder a homogeneizar todas las observaciones de acuerdo con el sistema de puntuación actual. De esta 
manera, podemos realizar una comparativa equilibrada en la capacidad de puntuar de todos los pilotos.
"""

# raceId de aquellas carreras a eliminar
race_id_to_eliminate = [2, 79, 1063]

# Eliminamos aquellas carreras que pueden introducir ruido en el modelo
dataset_reduced = dataset_reduced[~dataset_reduced['raceId'].isin(race_id_to_eliminate)]

"""Homogenización de las puntuciones"""

# Sistema de puntos de acuerdo con el reglamento vigente
# Diccionario {<posicion>: <puntos>}
reglamento_puntos = {1: 25.0,
                     2: 18.0,
                     3: 15.0,
                     4: 12.0,
                     5: 10.0,
                     6: 8.0,
                     7: 6.0,
                     8: 4.0,
                     9: 2.0,
                     10: 1.0
                     }

# 1 Establecemos las puntuaciones correspondientes de acuerdo a la posición obtenida al final de la carrera
dataset_reduced['driver_points'] = dataset_reduced.apply(lambda row: reglamento_puntos[row['final_position']] if (
            (row['final_position'] <= 10) & (row['final_position'] is not None)) else 0.0, axis=1)

# 2 Creamos una nueva columna para indicar si el piloto tiene la vuela rápida en carrera o no
dataset_reduced['vuelta_rapida'] = dataset_reduced.apply(lambda row: "yes" if row['fastest_lap_rank'] == 1 else "no",
                                                         axis=1)

# 3 Sumamos un punto a aquellos conductores que tengan la vuelta rápida y hayan quedado entre los 10 primeros puestos
dataset_reduced['driver_points'] = dataset_reduced.apply(
    lambda row: (row['driver_points'] + 1.0) if ((row['vuelta_rapida'] == "yes") & (row['final_position'] <= 10)) else
    row['driver_points'], axis=1)

# 4 Actualizamos la puntuación de los constrcutores de acuerdo con las nuevas puntuaciones calculadas
# Eliminamos los puntos de constructor desactualizados
dataset_reduced = dataset_reduced.drop('constructor_points', axis=1)
# Calculamos los puntos de constructor actualizados
constructor_points_new = dataset_reduced.copy().groupby(['raceId', 'constructorId'], as_index=False)[
    'driver_points'].sum()
constructor_points_new.rename(columns={'driver_points': 'constructor_points'}, inplace=True)
# Añadimos la nueva columna calculada al dataset original
dataset_reduced = dataset_reduced.merge(constructor_points_new, on=['raceId', 'constructorId'], how='left')

dataset_reduced.sort_values(['raceId', 'constructorId'])

# Realizamos una nueva comprobación de las puntuaciones tras los nuevos cambios
total_points_per_race = dataset_reduced.groupby(['raceId', 'race_year'], as_index=False).sum('driver_points')
total_points_per_race.rename(columns={'driver_points': 'total_driver_points'}, inplace=True)
total_points_per_race[['raceId', 'race_year', 'total_driver_points']].describe()

"""
Los nuevos datos parecen mucho mas coherentes y consistentes. 
Podemos observar que el número de puntos mínimos registrados en una carrera es 94. Estos valores corresponden a eventos 
en los que han finalizado la carrera menos de 10 competidores, ya sea por accidentes o averias.
Hemos decidido no eliminarlos, ya que en caso contario, podriamos perder información relevante sobre la fiabilidad de 
algunos pilotos.
"""

# Comprobamos la puntuación de los constructores
dataset_reduced[dataset_reduced['constructor_points'] > 44].sort_values(['race_year', 'raceId'])

# Data Summary después del preprocesado
df_data_summary_after_preprocessing = dataset_reduced.describe().reset_index().round(2)
df_data_summary_after_preprocessing.rename(columns = {'index': 'measure'}, inplace=True)

"""
No existe ningún caso en el que la puntuación de los constructores supere los límites posibles.
Confirmamos que los errores que hubieran podido haber en esta columna se han solucionado tras modificar las puntuaciones
en los apartados anteriores.
Creamos nuevas métricas que pueden resultar relevantes
"""

# Posiciones Ganadas en Carrera
# Diferencia negativa: ganancia de posiciones
# Diferencia positiva: pérdida de posiciones
dataset_reduced['positions_gain'] = dataset_reduced.apply(lambda row: row['final_position'] - row['start_position'],
                                                          axis=1)

# Porcentaje de los puntos de equipo obtenidos por cada conductor, sabiendo que en cada equipo hay 2 pilotos
dataset_reduced['percentage_points'] = dataset_reduced.apply(
    lambda row: (row['driver_points'] / row['constructor_points'] * 100) if row['constructor_points'] > 0 else 50.0,
    axis=1)

# Convertimos el race_status a variable numérica
# O: Finished
# 1: Vehicle Error
# 2: Pilot Error
dataset_reduced.replace(['Finished', 'Vehicle Error', 'Pilot Error'],
                        [0, 1, 2], inplace=True)

# Comprobación valores nulos después del preprocesado
df_null_values_after = pd.DataFrame(dataset_reduced.isna().sum().sort_values(ascending=False)).reset_index()
df_null_values_after.columns = ['Variable', 'Null Count']
df_null_values_after = df_null_values_after[df_null_values_after['Null Count'] > 0]

# Data Summary RELATIVE VARIABLES
# ===============================
# Extraemos un resumen de los datos para detectar anomalías
df_data_summary_new_vars = dataset_reduced[['race_status', 'positions_gain', 'percentage_points']].describe().reset_index().round(2)
df_data_summary_new_vars.rename(columns = {'index': 'measure'}, inplace=True)

# ========== #
# CLUSTERING #
# ========== #

'''
A la hora de introducir los datos en el modelo, vamos a agrupar los datos de cada piloto por temporada. De ese modo, 
podemos obtener una visión global del desempeño de los pilotos cada año y mitigamos la variabilidad fruto de los 
diferentes circuitos, meteorología o problemas técnicos.

Para ello, vamos a agrupar los datos de acuerdo a dos métricas diferentes:
* **Media**: muy sensible a los valores atípicos, pero da una visión adecuada del desempeño medio de la temporada.
* **Mediana:** menos sensible a los valores atípicos y proporciona una visión adecuada del desempeño de un piloto en 
condiciones normales.
'''

# Cargamos el modelo entrenado, el mejor de todos los probados
#modelo_entrenado = joblib.load('.//assets//models//modelo_entrenado.pkl')  # Carga del modelo.

# MODELO FINAL
# Tras examinar los resultados presentados en la tabla anterior, se ha podido comprobar de una forma más objetivo que
# el mejor modelo es...
#best_model_df = modelo_entrenado.copy()

# Cargamos el mejor modelo calculado
best_model_df = pd.read_csv('./assets/models/best_model.csv', index_col=0)


