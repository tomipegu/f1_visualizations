import numpy as np
import plotly.graph_objects as go
import dash
from dash import dcc, html, Input, Output, callback
import dash_bootstrap_components as dbc

import pages
from app import app

# Definimos el Layout de la App
app.layout = html.Div(
    [
        dcc.Location(id="url", refresh=True),
        html.Div(id="page-content"),
    ]
)

# [CALLBACK] Navegar entre páginas
@app.callback(Output("page-content", "children"), [Input("url", "pathname")])
def navigate_to_page(pathname):
    path = app.strip_relative_path(pathname)
    if not path:
        return pages.home.layout()
    elif path == "home":
        return pages.home.layout()
    elif path.startswith("eda/"):
        return pages.eda_main.layout()
    elif path.startswith("clustering/"):
        return pages.clustering_main.layout()
    elif path == "team":
        return pages.our_team.layout()
    else:
        return "404"

# Arrancamos el servidor
if __name__ == "__main__":
    app.run_server(debug=True)
