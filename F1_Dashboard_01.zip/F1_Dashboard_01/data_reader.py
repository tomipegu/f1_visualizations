# Page for readig the data, doing the calculations, preprocess of the data... for the exploratory data analysis (EDA)

import pandas as pd
import numpy as np
 
# Circuitos
circuitos = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/circuits.csv")
# Resultados Constructores
resultados_constructores = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets"
                                       "/constructor_results.csv")
# Standings Constructores
standing_constructores = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets"
                                     "/constructor_standings.csv")
# Constructores
constructores = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/constructors.csv")
# Standings Conductores
standing_conductores = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets"
                                   "/driver_standings.csv")
# Conductores
conductores = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/drivers.csv")
# Tiempos de Vuelta
tiempos_vuelta = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/lap_times.csv")
# Pit-Stops
pit_stops = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/pit_stops.csv")
# Histórico Qualifying
historico_clasificacion = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets"
                                      "/qualifying.csv")
# Histórico Carreras
historico_carreras = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/races.csv")
# Historico Resultados
historico_resultados = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/results.csv")
# Histórico Temporadas
historico_temporadas = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/seasons.csv")
# Historico Carreras Sprint
historico_sprint = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/sprint_results"
                               ".csv")
# Glosario Estados de Carrera (finalizado, retirado, avería, etc.)
estados_carrera = pd.read_csv("https://raw.githubusercontent.com/tomipegu/f1_visualizations/Datasets/status.csv")


# Fechas Carreras
fechas_carreras = historico_carreras.copy()[['raceId', 'date', 'year']]
fechas_carreras.rename(columns={'date': 'race_date', 'year': 'race_year'}, inplace=True)
# Conductores
conductores_reduced = conductores.copy()[['driverId', 'dob', 'nationality']]
# Resultados Constructores
resultados_constructores_reduced = resultados_constructores.copy()[['constructorId', 'raceId', 'points']]
resultados_constructores_reduced.rename(columns={'points': 'constructor_points'}, inplace=True)
# Resultados Carreras
resultados_carreras_reduced = historico_resultados.copy()[['raceId', 'driverId', 'constructorId', 'points', 'grid', 'position', 'rank', 'statusId']]
resultados_carreras_reduced.rename(columns={'points': 'driver_points', 'grid': 'start_position', 'position': 'final_position', 'rank': 'fastest_lap_rank'}, inplace=True)
# Status Carreras
estados_carreras_reduced = estados_carrera.copy()
# Clasificación de los posibles estados de carrera
status_conditions = [
    (estados_carreras_reduced['statusId'] == 1),
    (estados_carreras_reduced['statusId'] > 1) & (estados_carreras_reduced['statusId'] <= 4),
    (estados_carreras_reduced['statusId'] > 4)
]
status_values = ['Finished', 'Pilot Error', 'Vehicle Error']
estados_carreras_reduced['race_status'] = np.select(status_conditions, status_values)
# Eliminamos las categorías antiguas
estados_carreras_reduced = estados_carreras_reduced.drop('status', axis=1)
# Dataset Modelo
dataset_reduced = conductores_reduced.merge(resultados_carreras_reduced, on='driverId', how='left') \
                                     .merge(resultados_constructores_reduced, on=['raceId', 'constructorId'], how='left') \
                                     .merge(estados_carreras_reduced, on=['statusId'], how='left') \
                                     .merge(fechas_carreras, on='raceId', how='left')

# PREPROCESADO - Comprobación de Variables
# Aquellos valores que contengan '\\N' los consideramos como nulos
dataset_reduced.loc[dataset_reduced["final_position"] == "\\N", "final_position"] = None
dataset_reduced.loc[dataset_reduced["fastest_lap_rank"] == "\\N", 'fastest_lap_rank'] = None

# Convertimos la Posición Final y el Ranking de Vuelta Rápida a Int
dataset_reduced = dataset_reduced.copy().astype({'final_position': 'float', 'fastest_lap_rank': 'float'})
dataset_reduced = dataset_reduced.copy().astype({'final_position': 'Int64', 'fastest_lap_rank': 'Int64'})


# Edad Conductores
dataset_reduced['dob'] = dataset_reduced.apply(lambda row: int(((pd.to_datetime(row['race_date'])-pd.to_datetime(row['dob'])).days/365.2)), axis=1)
dataset_reduced.rename(columns={"dob": "age"}, inplace=True)
# Nos quedamos solo con las columnas relevantes
dataset_reduced_columns = ['driverId', 'age', 'nationality', 'raceId', 'constructorId', 'driver_points', 'start_position', 'final_position', 'fastest_lap_rank', 'constructor_points', 'statusId', 'race_status', 'race_year']
dataset_reduced = dataset_reduced[dataset_reduced_columns]


# Nacionalidad conductores
df_nacionalidad_conductores = dataset_reduced.copy()[['driverId', 'nationality', 'race_year']].drop_duplicates(inplace=False)

# Posición conductores
df_posiciones_conductores = conductores.merge(standing_conductores, left_on='driverId', right_on='driverId', how='left') \
                                       .merge(historico_carreras, on='raceId', how='left')


# CAMPEONES F1 por año
df_f1_champions = df_posiciones_conductores.groupby(['driverId', 'year', 'nationality'])[['points', 'wins']].max().sort_values('points', ascending=False).reset_index()
df_f1_champions.drop_duplicates(subset=['year'], inplace=True)
# Lista de conductores que fueron campeones alguna vez
list_f1_champions = list(df_f1_champions['driverId'].unique())
# Extraemos información detallada de los conductores campeones
df_f1_champions_info = df_posiciones_conductores.copy()[df_posiciones_conductores['driverId'].isin(list_f1_champions)]


# RAKING Constructores por Año
df_posiciones_constructores = constructores.merge(standing_constructores, how="inner", on=["constructorId"]) \
                                           .rename(columns={"name": "constructor_name"}) \
                                           .merge(historico_carreras, on='raceId', how='left')

df_constructor_ranking = df_posiciones_constructores.groupby(['constructorId', 'constructor_name', 'year', 'nationality'])[['points', 'wins']].max().sort_values(['year', 'points'], ascending=False).reset_index()
df_constructor_ranking.columns = ['constructorId', 'Constructor', 'Year', 'Nationality', 'Points', 'Wins']

# Número de campeonatos de cada Escudería
df_constructor_years = df_constructor_ranking.groupby(['constructorId', 'Constructor'])['Year'].count().reset_index(name="numero_campeonatos").sort_values("numero_campeonatos", ascending=False)


# Información conductores
# Datos Personales
df_driver_info = conductores.copy()
df_driver_info['name'] = df_driver_info['forename'] + " " + df_driver_info['surname']
df_driver_info = df_driver_info[['driverId', 'name', 'code', 'dob', 'nationality', 'url']].set_index('driverId')
# Número de victorias conductores
df_driver_info['race_wins'] = df_posiciones_conductores.groupby(['driverId', 'year', 'nationality'])[['wins']].max().sort_values(['wins', 'year', 'driverId'], ascending=False).reset_index() \
                                          .groupby(['driverId']).sum('wins').sort_values(['wins', 'driverId'], ascending=False)['wins']
# Número de campeonatos del mundo conductores
df_driver_info['season_wins'] = df_f1_champions.groupby(['driverId'])['year'].count()
# Número de poles conductores
df_driver_info['num_poles'] = dataset_reduced[dataset_reduced['start_position'] == 1].groupby('driverId')['raceId'].count()
# Número de podiums conductores
df_driver_info['num_podiums'] = dataset_reduced[(dataset_reduced['final_position'] > 0) & (dataset_reduced['final_position'] < 4)].groupby('driverId')['raceId'].count()
# Número de temporadas conductores
df_driver_info['num_seasons'] = df_posiciones_conductores[['driverId', 'year']].drop_duplicates().groupby('driverId')['year'].count()
# Sustituimos los valores nulos por 0
df_driver_info.fillna(0.0, inplace=True)
df_driver_info = df_driver_info.reset_index()

# Información conductores ANUAL
# Número de victorias conductores por año
df_driver_yearly_info = df_posiciones_conductores.groupby(['driverId', 'year'])[['wins']].max().sort_values(['driverId', 'year', 'wins'])
# Número de poles conductores por año
df_driver_yearly_info['num_poles'] = dataset_reduced[dataset_reduced['start_position'] == 1].groupby(['driverId', 'race_year'])['raceId'].count()
# Número de podiums conductores por año
df_driver_yearly_info['num_podiums'] = dataset_reduced[(dataset_reduced['final_position'] > 0) & (dataset_reduced['final_position'] < 4)].groupby(['driverId', 'race_year'])['raceId'].count()
# Sustituimos los valores nulos por 0
df_driver_yearly_info.fillna(0.0, inplace=True)
df_driver_yearly_info = df_driver_yearly_info.reset_index()
# Datos Personales
df_driver_yearly_info = df_driver_yearly_info.merge(df_driver_info[['driverId', 'name']], on='driverId', how='left')
